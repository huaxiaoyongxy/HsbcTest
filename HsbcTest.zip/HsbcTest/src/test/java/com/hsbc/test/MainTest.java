package com.hsbc.test;

import org.junit.jupiter.api.Test;
import org.springframework.util.PropertyPlaceholderHelper;

import java.util.OptionalInt;
import java.util.stream.IntStream;
import static org.junit.jupiter.api.Assertions.*;

public class MainTest {

    private static final char a_ = 'a';

    private static final char PLACEHOLDER_PREFIX = '{';

    private static final char PLACEHOLDER_SUFFIX = '}';

    protected static final PropertyPlaceholderHelper HELPER = new PropertyPlaceholderHelper(
            String.valueOf(PLACEHOLDER_PREFIX), String.valueOf(PLACEHOLDER_SUFFIX));

    /**
     * Example:
     * Input: aabcccbbad
     * Output:
     * -> aabbbad
     * -> aaad
     * -> d
     */
    @Test
    public void test01(){
        String result = "";
        String str = "aabcccbbad";
        char[] charArray = str.toCharArray();
        while(findAndReplace(charArray).isPresent()) {
            result = char2String(charArray, name -> "");
            System.out.println(result);
            charArray = result.toCharArray();
        }
        assertEquals(result, "d");
    }

    /**
     * Input: abcccbad
     * Output:
     * -> abbbad, ccc is replaced by b
     * -> aaad, bbb is replaced by a
     * -> d
     */
    @Test
    public void test02() {
        String str = "abcccbad";
        String result = "";
        char[] results = new char[2];
        char[] charArray = str.toCharArray();
        while(findAndReplace(charArray).isPresent()) {
            result = char2String(charArray, name -> {
                char c = name.charAt(0);
                results[0] = c;
                if (c == a_) {
                    return "";
                }
                char before = (char) ((int) c - 1);
                results[1] = before;
                return String.valueOf(before);
            });
            if (results[0] == a_) {
                System.out.println(result);
            } else {
                System.out.printf("%s, %s%s%s is replaced by %s%n", result, results[0], results[0], results[0], results[1]);
            }
            charArray = result.toCharArray();
        }
        assertEquals(result, "d");
    }

    private static String char2String(char[] chars
            , PropertyPlaceholderHelper.PlaceholderResolver placeholderResolver){
        if (chars == null || chars.length == 0) {
            return "";
        }
        return HELPER.replacePlaceholders(String.valueOf(chars), placeholderResolver);
    }

    private static OptionalInt findAndReplace(char[] chars){
        if (chars == null || chars.length == 0) {
            return OptionalInt.empty();
        }
        return IntStream.range(0, chars.length - 2)
                .filter(i -> chars[i] == chars[i + 1] && chars[i] == chars[i + 2])
                .peek(i -> {
                    chars[i] = PLACEHOLDER_PREFIX;
                    chars[i + 2] = PLACEHOLDER_SUFFIX;
                })
                .findFirst();
    }

}
